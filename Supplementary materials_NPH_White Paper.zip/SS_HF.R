#
# TITLE: Sample Size Estimation with Harrington-Fleming Weighted Log Rank test
#        for Delayed Onset Time under Piecewise Exponential Distribution
# NAME: Takahiro Hasegawa
# ORIGINAL DATE: February 11, 2013
# MODIFIED DATE: February 17, 2013 (Hazard ratio after delayed onset time is output)
#                March    27, 2013 (Number of events needed is output)
#                January  18, 2018 Keaven Anderson changed from medians to hazard rate and
#                   hazard ratio specification. Also allowed HR different than 1 prior to delay.
#                   Finally, output results rather than printing them.
#-----------------------------------------------------------------------------
# PARAMETERS: H = Hazard rate or rates for group 1
#             HR = Hazard ratio (group 2/group 1) before and after delayed onset time point
#             EPS = Delayed onset time in group 2
#             B = Number of subintervals per time unit for computation
#             AT = Accrual time
#             TAU = Postaccrual follow-up time
#             W1 = Weight for sample size in group 1
#             W2 = Weight for sample size in group 2
#             P = Parameter p of Harrington-Fleming weight: S(t)^p*{1-S(t)}^q
#             Q = Parameter q of Harrington-Fleming weight: S(t)^p*{1-S(t)}^q
#             ALPHA = One-sided significance level
#             POWER = Power
#

SS_HF <- function(H,HR,EPS,B,AT,TAU,W1=1,W2=1,P=0,Q=1,ALPHA=0.05,POWER=0.90){
  M <- floor((AT+TAU)*B)
  tp <- seq(0,AT+TAU,length.out=(M+1))
  h <- matrix(NA,2,M+1)
  h[1,] <- H
  h[2,tp<EPS] <- H*HR[1]
  h[2,tp>=EPS] <- H*HR[2]
  theta <- h[2,]/h[1,]
  N <- matrix(NA,2,M+1)
  N[1,1] <- W1/(W1+W2)
  N[2,1] <- W2/(W1+W2)
  for (i in 1:M){
    for (j in 1:2){
      N[j,i+1] <- N[j,i]*(1-h[j,i]/B-(1/B/(AT+TAU-tp[i]))*(tp[i]>TAU))
    }
  }
  phi <- N[2,]/N[1,]
  Di <- (h[1,]*N[1,]+h[2,]*N[2,])/B
  S <- matrix(NA,2,M+1)
  S[1,] <- exp(-H*tp)
  S[2,tp<EPS] <- exp(-H * HR[1] *tp[tp<EPS])
  S[2,tp>=EPS] <- exp(-H*HR[1]*EPS)*exp(-H*HR[2]*(tp[tp>=EPS]-EPS))
  cS <- W1/(W1+W2)*S[1,]+W2/(W1+W2)*S[2,]
  r <- cS^P*(1-cS)^Q

  Di <- Di[-(M+1)]
  r <- r[-(M+1)]
  phi <- phi[-(M+1)]
  theta <- theta[-(M+1)]
  E <- sum(Di*r*(phi*theta/(1+phi*theta)-phi/(1+phi)))/sqrt(sum(Di*r^2*phi/(1+phi)^2))

  result <- numeric(7)
#  names(result) <- c("Hazard ratio after delayed onset time","Total N",
#                     "N in group 1","N in group 2","Number of events needed",
#                     "Number of events needed after delayed onset time",
#		     "HR before delayed onset time")
  result[2] <- ((qnorm(1-ALPHA)+qnorm(POWER))/E)^2
  result[3] <- ceiling(result[2]*W1/(W1+W2))
  result[4] <- ceiling(result[3]*W2/W1)
  result[2] <- sum(result[3:4])
  result[5] <- ceiling(result[2]*sum(Di))
  result[6] <- ceiling(result[2]*sum(Di[(EPS*B+1):length(Di)]))
  result[7] <- HR[1]
  result[1] <- HR[2]
  return(data.frame(FollowUp=TAU,HRpre=result[7],HRpost=result[1],N=result[2],
                    N1=result[3],N2=result[4],Events=result[5],EventsPost=result[6]))
#  print(result[1])
#  print(result[2:4])
#  print(result[5])
#  print(result[6])
#  print(result[7])
}

